A Pen created at CodePen.io. You can find this one at http://codepen.io/jbltx/pen/WbdRRb.

 md-table custom element
Attributes :
-headers : Array of objects which include "name" and "field" keys for table columns.
-content : Array of object which is the content of table rows.
-sortable : StringArray with name of sortable columns.
-filters : String which filters rows in table (here a ng-model is used).
-customClass : Object with columns names as keys and class names as values.
-thumb : String equals to the thumbs column name.
-count : Number equals to the number rows present per pages by default.