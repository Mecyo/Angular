# OpenUI5 table example working as a Angular.js directive

A blank web project

## Install Via npm

It installs node packages, bower dependencies and PHP vendors

```
npm install
```

## Pre-requisites

* npm (brew install npm / apt-get install npm)
* bower (npm install bower -g)
* grunt-cli (npm install grunt-cli -g)
* composer (curl -sS https://getcomposer.org/installer | php)
